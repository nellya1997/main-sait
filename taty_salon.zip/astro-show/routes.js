const apiPath = '/api';


const routes = {
  sendEmail: [apiPath, 'send-email'].join('/'),
  sendEmailPay: [apiPath, 'send-email-pay'].join('/'),
};
